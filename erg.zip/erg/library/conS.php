<?php

$koneksi = mysqli_connect('localhost', 'root', '', 'report');
if (!$koneksi) {
    die("Gagal koneksi ke database" . mysqli_connect_error());
}
