<?php
include '../library/conS.php';

//CEK APAKAH KDTK DAN TANGGAL ADA DI URL
if (isset($_GET['KDTK']) && isset($_GET['TANGGAL'])) {
    $KDTK = $_GET['KDTK'];
    $TANGGAL = $_GET['TANGGAL'];

    //AMBIL DATA BERDASARKAN KDTK DAN TANGGAL
    $sql = "SELECT * FROM rekap_perbaikan_errlog where KDTK = ? AND TANGGAL = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("ss", $KDTK, $TANGGAL);
    $stmt->execute();
    $result = $stmt->get_result();

    //CEK DATA JIKA DITEMUKAN
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
    } else {
        echo "Data tidak ada";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //ambil data dari form
    $KDTK = $_POST['KDTK'];
    $TANGGAL = $_POST['TANGGAL'];
    $CABANG = $_POST['CABANG'];
    $SIZE_KEMARIN = $_POST['SIZE_KEMARIN'];
    $SIZE_HARIH = $_POST['SIZE_HARIH'];
    $selisih_MB = $_POST['selisih_MB'];
    $KETERANGAN = $_POST['KETERANGAN'];
    $STATUS = $_POST['STATUS'];

    //update data yang di database
    $sql = "UPDATE rekap_perbaikan_errlog set KETERANGAN = ?, `STATUS` = ? where KDTK = ? AND TANGGAL = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param('ssss', $KETERANGAN, $STATUS, $KDTK, $TANGGAL);
    if ($stmt->execute()) {
        //balik ke halaman rekap
        header('Location: table.php?status=sukses');
        exit();
    } else {
        echo "Gagal edit data: " . $koneksi->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Perbaikan Errlog</title>
    <link rel="stylesheet" href="../library/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../library/bootstrap/css/datatables.min.css">
    <link rel="stylesheet" href="../library/bootstrap/css/datatables.bootstrap5.css">
    <style>
        .mx-auto {
            width: 800px;
        }

        .card {
            margin-top: 20px;
        }

        input[readonly] {
            background-color: #DCDCDC;
            /* Warna abu-abu muda */
            border: 1px #DCDCDC;
            /* Border warna abu */
        }
    </style>
</head>

<body>
    <div class="mx-auto">
        <!-- untuk memasukan data -->
        <div class="card">
            <div class="card-header text-white bg-success">
                Edit Data
            </div>

            <div class="card-body">
                <form action="update.php" method="POST">
                    <div class="mb-3">
                        <label for="KDTK" class="form-label">Kode Toko</label>
                        <input type="text" class="form-control" id="KDTK" name="KDTK" value="<?php echo htmlspecialchars($data['KDTK']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="TANGGAL" class="form-label">Tanggal</label>
                        <input type="date" class="form-control" id="TANGGAL" name="TANGGAL" value="<?php echo htmlspecialchars($data['TANGGAL']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="CABANG" class="form-label">Cabang</label>
                        <input type="text" class="form-control" id="CABANG" name="CABANG" value="<?php echo htmlspecialchars($data['CABANG']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="SIZE_KEMARIN" class="form-label">Size Kemarin</label>
                        <input type="text" class="form-control" id="SIZE_KEMARIN" name="SIZE_KEMARIN" value="<?php echo htmlspecialchars($data['SIZE_KEMARIN']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="SIZE_HARIH" class="form-label">Size HariH</label>
                        <input type="text" class="form-control" id="SIZE_HARIH" name="SIZE_HARIH" value="<?php echo htmlspecialchars($data['SIZE_HARIH']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="selisih_MB" class="form-label">selisih_mb</label>
                        <input type="text" class="form-control" id="selisih_MB" name="selisih_MB" value="<?php echo htmlspecialchars($data['selisih_MB']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="KETERANGAN" class="form-label">Keterangan</label>
                        <input type="text" class="form-control" id="KETERANGAN" name="KETERANGAN" value="<?php echo htmlspecialchars($data['KETERANGAN']) ?>">
                    </div>
                    <div class="mb-3">
                        <label for="STATUS" class="form-label">Status</label>
                        <input type="text" class="form-control" id="STATUS" name="STATUS" value="<?php echo htmlspecialchars($data['STATUS']) ?>">
                    </div>
                    <button type="submit" class="btn btn-success">Simpan Perubahan</button>
                </form>
            </div>
        </div>
    </div>



    <script src="../library/bootstrap/js/jquery.min.js"></script>
    <script src="../library/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
        // Cek apakah URL mengandung parameter status=success
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('status') && urlParams.get('status') === 'success') {
            // Tampilkan alert jika data berhasil diedit
            alert('Data berhasil diedit!');
        }
    </script>
</body>

</html>