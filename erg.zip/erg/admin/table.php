<?php
include '../library/conS.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Perbaikan Errlog</title>
    <link rel="stylesheet" href="../library/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../library/bootstrap/css/datatables.min.css">
    <link rel="stylesheet" href="../library/bootstrap/css/datatables.bootstrap5.css">
    <style>
        .mx-auto {
            width: 1300px;
        }

        .card {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h3 class=" text-success fw-bold">Rekap Errlog Period 2024</h3>
    </div>
    <div class="container mt-5">
        <!-- Tombol untuk memunculkan modal -->
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Info
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">informasi terkait</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Errlog muncul jika ada nya, selisih_Mb di atas 0.50Mb dan di perlukan pengecekan dikarenakan adanya masalah pada table sql pada toko entah rusak atau tidak terbaca.
                        <span class="text-success">========================================</span>
                        <br>
                        jika menemukan Error (Error page) di errlog.err Toko maka info ke Grup untuk Backup Restore, juga tambahakan ket di tabel bawah
                        <span class="text-success">========================================</span>
                        <br>
                        Status Sudah OK, jika toko sudah di kerjakan
                        <span class="text-success">========================================</span>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>

    <div class="mx-auto">
        <!-- untuk menampilkan data -->
        <div class="card">
            <div class="card-header">
                Rekap Errlog
            </div>
            <div class="card-body">
                <table id="rekap" class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Kode Toko</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Cabang</th>
                            <th scope="col">Size Kemarin</th>
                            <th scope="col">Size HariH</th>
                            <th scope="col">Selisih</th>
                            <th scope="col">Keterangan</th>
                            <th scope="col">Status</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql2 = "select * from rekap_perbaikan_errlog order by tanggal desc";
                        $q2 = mysqli_query($koneksi, $sql2);
                        while ($r2 = mysqli_fetch_array($q2)) {
                            $KDTK = $r2['KDTK'];
                            $TANGGAL = $r2['TANGGAL'];
                            $CABANG = $r2['CABANG'];
                            $SIZE_KEMARIN = $r2['SIZE_KEMARIN'];
                            $SIZE_HARIH = $r2['SIZE_HARIH'];
                            $selisih_MB = $r2['selisih_MB'];
                            $KETERANGAN = $r2['KETERANGAN'];
                            $STATUS = $r2['STATUS'];

                        ?>
                            <tr>
                                <td scope="row"><?php echo $KDTK ?></td>
                                <td scope="row"><?php echo $TANGGAL ?></td>
                                <td scope="row"><?php echo $CABANG ?></td>
                                <td scope="row"><?php echo $SIZE_KEMARIN ?></td>
                                <td scope="row"><?php echo $SIZE_HARIH ?></td>
                                <td scope="row"><?php echo $selisih_MB ?></td>
                                <td scope="row"><?php echo $KETERANGAN ?></td>
                                <td scope="row"><?php echo $STATUS ?></td>
                                <td scope="row">
                                    <a href="update.php?KDTK=<?php echo urlencode($KDTK); ?>&TANGGAL=<?php echo urlencode($TANGGAL); ?>" class="btn btn-warning">Edit</a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>






    <script src="../library/bootstrap/js/jquery.min.js"></script>
    <script src="../library/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../library/bootstrap/js/datatables.min.js"></script>
    <script src="../library/bootstrap/js/dataTables.bootstrap5.js"></script>

    <script>
        $(document).ready(function() {
            $('#rekap').DataTable();
        });
    </script>
</body>

</html>